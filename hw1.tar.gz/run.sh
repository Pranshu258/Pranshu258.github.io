python trajectory.py 0 99
python trajectory.py 1 999
python trajectory.py 2 99
python trajectory.py 3 99

python manifold.py 0
python manifold.py 1
python manifold.py 2
python manifold.py 3